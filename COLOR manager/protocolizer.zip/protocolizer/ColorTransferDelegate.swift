//
//  ColorTransferDelegate.swift
//  protocolizer
//
//

import UIKit

protocol ColorTranferDelegate {
    func userDidChoose(color: UIColor, withName colorName: String)
}
