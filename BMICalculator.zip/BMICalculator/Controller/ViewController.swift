//
//  ViewController.swift
//  BMICalculator
//
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imgLogoNew: UIImageView!
    @IBOutlet weak var bmiResult: UILabel!
    @IBOutlet weak var categoryResult: UILabel!
    @IBOutlet weak var inputHeight: UITextField!
    @IBOutlet weak var inputWeight: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func calculateBtn(_ sender: Any) {
        let bmi: Float = Float(inputWeight.text!)! / pow((Float(inputHeight.text!)! / 100), 2)
        let bmiString = NSString(format: "%.1f", bmi)
        bmiResult.text = bmiString as String
        if (bmi < 18.5) {
            imgLogoNew.image = UIImage(named: "Under")
            categoryResult.text = "Underwight"
        } else if (bmi >= 18.5 && bmi < 25) {
            imgLogoNew.image = UIImage(named: "Nor.png")
            categoryResult.text = "Normal"
        } else if (bmi >= 25 && bmi < 30) {
            imgLogoNew.image = UIImage(named: "Over.png")
            categoryResult.text = "Overweight"
        } else if (bmi >= 30 && bmi < 35) {
            imgLogoNew.image = UIImage(named: "Ob.png")
            categoryResult.text = "Obese"
        } else {
            imgLogoNew.image = UIImage(named: "Ex.png")
            categoryResult.text = "Extremely Obese"
        }
    }
}

